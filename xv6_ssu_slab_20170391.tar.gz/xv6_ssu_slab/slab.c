#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "spinlock.h"
#include "slab.h"
#include "stdbool.h"
#include "stdio.h" 

struct {
	struct spinlock lock;
	struct slab slab[NSLAB];
} stable;

void slabinit(){
	initlock(&stable.lock, "stable");
	struct slab* sl;
	int i = 0;
	acquire(&stable.lock);
	for(sl = stable.slab;sl < &stable.slab[NSLAB];sl++){
		sl->size = 1 << (i+3);
		sl->num_free_objects = PGSIZE >> (i + 3);
		i++;
		sl->num_pages = 1;
		sl->num_used_objects = 0;
		sl->num_objects_per_page = sl->num_free_objects;
		
		sl->bitmap = kalloc();
		memset(sl->bitmap, 0, PGSIZE);

		sl->page[0] = kalloc();
		memset(sl->page[0], 1, PGSIZE);
	}
	release(&stable.lock);
}

char *kmalloc(int size){
	if(size < 0 || size >2048)
		return 0;
	int req;
	for(int i=0;i<NSLAB;i++){
		req = size >> (i + 3);
		if(req == 0){
			req = i;
			break;
		}
	}
	acquire(&stable.lock);
	if(stable.slab[req].num_free_objects == 0){
		stable.slab[req].num_pages += 1;
		stable.slab[req].page[stable.slab[req].num_pages-1] = kalloc();
		memset(stable.slab[req].page[stable.slab[req].num_pages-1], 1, PGSIZE);
		stable.slab[req].num_free_objects += stable.slab[req].num_objects_per_page;
	}

	int k = 0;
	int j = 0;
	for(k=0;k<stable.slab[req].num_free_objects;k++){
		char bit = *(stable.slab[req].bitmap + k/8);
		char chbit1 = bit >> j;
		char chbit2 = chbit1 & 1;
		
		if(chbit2 == 0)
			break;
		
		j = k % 8;
	}
	stable.slab[req].num_used_objects++;
	stable.slab[req].num_free_objects--;	
	*(stable.slab[req].bitmap + k/8) |= (1<<j);	

	char* ret = stable.slab[req].page[stable.slab[req].num_pages-1] 
					+ stable.slab[req].size * k % stable.slab[req].num_objects_per_page;

	release(&stable.lock);

	return ret;
}

void kmfree(char *addr, int size){
	if(size < 0 || size > 2048){}
	else{
		int req = size >> 3;
		if(size > 0)
		for(int i=0;i<MAX_PAGES_PER_SLAB;i++){
			req = req >> i;
			if(req == 0){
				req = i;
				break;
			}
		}
		
		acquire(&stable.lock);
		int i = 0;
		int j = 0;
		int k = 0;
		for(i=0;i<stable.slab[req].num_pages;i++){
			for(k=0;k < stable.slab[req].num_objects_per_page;k++){
				if(addr == stable.slab[req].page[i] + stable.slab[req].size * k % stable.slab[req].num_objects_per_page){	
					stable.slab[req].num_used_objects--;
					stable.slab[req].num_free_objects++;	
					*(stable.slab[req].bitmap + k/8) &= ~(1<<j);		
					memset(addr, 1, stable.slab[req].size);
					break;
				}
				j = k % 8;
			}
		}
		release(&stable.lock);
	}
}

void slabdump(){
	cprintf("__slabdump__\n");

	struct slab *s;

	cprintf("size\tnum_pages\tused_objects\tfree_objects\n");

	for(s = stable.slab; s < &stable.slab[NSLAB]; s++){
		cprintf("%d\t%d\t\t%d\t\t%d\n", 
			s->size, s->num_pages, s->num_used_objects, s->num_free_objects);
	}
}
